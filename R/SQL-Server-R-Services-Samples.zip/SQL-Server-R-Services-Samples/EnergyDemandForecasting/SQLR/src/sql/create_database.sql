create database $(DBName);
GO


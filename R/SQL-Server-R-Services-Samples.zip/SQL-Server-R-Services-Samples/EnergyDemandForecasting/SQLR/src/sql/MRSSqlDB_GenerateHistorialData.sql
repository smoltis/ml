use $(DBName); 
go

execute [dbo].[usp_GenerateHistorcialData] 
 
select getdate()

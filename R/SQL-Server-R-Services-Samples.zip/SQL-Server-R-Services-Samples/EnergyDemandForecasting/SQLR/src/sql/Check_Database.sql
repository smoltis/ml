use $(DBName);
GO

select getdate()
